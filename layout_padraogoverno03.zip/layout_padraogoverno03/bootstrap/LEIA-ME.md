Versão do bootstrap customizada, com download realizado em: http://getbootstrap.com/2.3.2/customize.html
Alterações com motivo de adequação à 960 pixels de largura máxima.

Alterações:
---------------------------------------------------
Base CSS > Icons - RETIRADO
Miscellaneous > Wells - RETIRADO
Responsive > Large desktops (>1200px) - RETIRADO
Grid System > @gridColumnWidth - 60x para 50px
Grid System > @gridGutterWidth - 20px para 30px